const scrollToTopBtn = document.getElementById("scrollToTopBtn");
window.onscroll = function() {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        scrollToTopBtn.classList.add("show");
    } else {
        scrollToTopBtn.classList.remove("show");
    }
};
scrollToTopBtn.addEventListener("click", function() {
    window.scrollTo({ top: 0, behavior: "smooth" });
});



// Wait for the DOM to fully load
document.addEventListener('DOMContentLoaded', () => {
    // Select the menu toggle button and nav links
    const menuToggle = document.getElementById('menu-toggle');
    const navLinks = document.getElementById('nav-links');

    // Add click event listener to the menu toggle button
    menuToggle.addEventListener('click', () => {
        // Toggle the active class on the nav links
        navLinks.classList.toggle('active');
    });
});




document.addEventListener('DOMContentLoaded', () => {
    const orderButton = document.getElementById('order-now');

    // Event listener for the 'Order Now' button
    orderButton.addEventListener('click', () => {
        // Redirect or perform an action when the button is clicked
        window.location.href = "#menu"; // Adjust to the desired link or function
    });

    // Optional: Add Hero Background Slideshow or Animation (Fade Effect)
    const heroImages = [
        'assets/images/hero-bg1.jpg', // Image 1
        'assets/images/hero-bg2.jpg', // Image 2
        'assets/images/hero-bg3.jpg'  // Image 3
    ];

    let currentImageIndex = 0;
    const heroSection = document.querySelector('.hero');

    // Function to change background image every few seconds
    function changeHeroBackground() {
        currentImageIndex = (currentImageIndex + 1) % heroImages.length;
        heroSection.style.backgroundImage = `url('${heroImages[currentImageIndex]}')`;
    }

    // Change background every 5 seconds
    setInterval(changeHeroBackground, 5000);
});
